package com.example.rentingroom.Views

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.rentingroom.Room.RentingDao

/**
 * Función que diseña la vista de la Gestión de una reserva.
 */
@Composable
fun Gestion (navController: NavController, dao: RentingDao, context: Context) {



}