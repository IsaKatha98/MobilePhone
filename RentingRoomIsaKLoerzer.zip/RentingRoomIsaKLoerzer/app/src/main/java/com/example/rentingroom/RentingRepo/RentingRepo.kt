package com.example.rentingroom.RentingRepo

import androidx.lifecycle.MutableLiveData
import com.example.rentingroom.Entities.Habitaciones
import com.example.rentingroom.Room.RentingDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RentingRepo (private val dao:RentingDao) {


}