package com.example.rentingroom.Views

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.rentingroom.Room.RentingDao

/**
 * Función que diseña la vista de la Configuracion.
 */
@Composable
fun Configuracion (navController: NavController, dao: RentingDao, context: Context) {



}